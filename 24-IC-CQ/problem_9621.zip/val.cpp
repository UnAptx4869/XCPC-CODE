#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
int n,m;
int main (int argc,char* argv[]) {
	registerValidation(argc,argv);
	n=inf.readInt(2,1000);
	inf.readSpace();
	m=inf.readInt(2,1000);
	inf.readChar('\n');
	inf.readEof();
	return 0;
}
